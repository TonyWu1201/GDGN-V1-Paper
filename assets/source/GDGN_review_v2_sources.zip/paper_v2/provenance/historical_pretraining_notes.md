# Historical pretraining definition

Read-only inspection on 2026-10-12. The description in Section 5 is recovered from the B4-era source at commit `b57c8bf`:

- `program/model/pretrain.py`: dynamic edge masking, per-cell omics injection and relation prediction against sampled negatives.
- `program/model/pretrain_loss.py`: relation-specific binary cross-entropy, a weighted drug--gene term, and an optional drug--gene pairwise margin term.
- `program/model/pretrain_encoder.py`: heterogeneous gene/drug encoder with static features and cellular omics.

The manuscript describes the historical implementation. The source defaults are not presented as confirmed settings of every archived checkpoint. The downstream configurations establish whether encoder initialization was requested. The current verification report has `smoke: True`; its AUC/AP values are excluded from the manuscript and do not establish the full pretraining run.

Inspection commands used `git show b57c8bf:<source path>`. No Python model module was imported, no graph data were loaded, and no training or inference was run.
