# Historical attribution-code provenance

Date: 2026-10-12. Read-only inspection of model history; no model execution.

## Saved snapshot

- Source commit: `6e82935bf4f1295ad5eb9682491c2abf95af7492` (2026-08-01).
- Source: `program/model/interpret.py` at that commit.
- Saved file: `paper_v1/provenance/historical_interpret_6e82935.py`.
- Extraction: `git show 6e82935:program/model/interpret.py`, capturing raw stdout bytes through Python `subprocess.run` and writing those bytes unchanged.
- Size: 25,134 bytes.
- SHA256: `01ed239fe5ca48c9d98707af68a070b0d2ab4716a14eaf4c7d1039f7c15cea8f`.

## What the historical implementation defines

`build_forward_fn` (line 137) defines a function of the four-channel omics tensor while capturing the observed pathway vector as a detached constant. The cell and drug identities remain fixed. The function returns the complete predictor's continuous output. For B4, omics gradients therefore traverse the graph branch and flatten branch, conditional on the observed pathway input; they do not include an expression-to-pathway recomputation chain.

`ig_attribution` (line 161) aggregates signed channel attributions into `sqrt(sum(attr**2, dim=-1))`. The saved gene-level score is the L2 norm of expression, mutation, copy-number and methylation IG. Reconstructing these norms from all ten saved `ig_channels` arrays agrees with `ig_per_gene` to a maximum absolute discrepancy of approximately `1.91e-9` (floating-point precision).

The historical source defaults to 50 integration steps and the `mean` reference (CLI lines 442 and 444); the mean is calculated per gene/channel over all cell lines loaded in `clf`, not over a training-only cohort. A `zero` reference and custom integration-step count can be requested. `--smoke` reduces steps to at most 10. These are **source defaults and options**, not confirmed command-line arguments of the archived run. The records do not preserve `n_steps`, reference choice, smoke flag, convergence delta, run command or checkpoint hash. The manuscript should specify the conditional function and L2 aggregation, and distinguish default settings from recorded run settings.

## Evidence associating the records with B4

The same commit introduces both the attribution script and `data/model/interpretability/gdgn_b4/cases.json`. `_default_ckpt("gdgn")` (line 526) resolves to `data/model/arch/B4_dual_encoder/best_model.pt`, and the script's usage example explicitly combines that checkpoint with the `gdgn_b4` directory. The current cases file and the file committed in `6e82935` have identical parsed JSON content. Their byte-level Git object IDs differ because the working file uses CRLF and the committed file uses LF; no JSON value difference was found.

This provides a strong source-history association with the B4 interpretation run. Each individual record lacks a checkpoint path/hash, so the archive does not independently certify the exact weight bytes used. Appropriate wording is “the ten records archived for the B4 interpretation run,” accompanied by the general retrospective-provenance scope. No inference was rerun to establish model identity.

The historical commit is thus a directly corresponding source snapshot, rather than an arbitrary candidate chosen from a recent script version. It still cannot certify whether the working tree contained uncommitted changes at the original run or which optional CLI arguments were supplied.

## Difference from the current working-tree implementation

The current `program/model/interpret.py` jointly attributes the omics tensor and the pathway input, returns pathway attributions and convergence delta, and records extra fields. Those changes are absent from the ten archived B4 records. The current implementation must not be used to retrospectively claim joint-pathway interpolation, numerical completeness verification, or confirmed reference settings for the old results.

The saved snapshot is for provenance and inspection. It is not imported by the reanalysis script and does not replace the project's current code.
