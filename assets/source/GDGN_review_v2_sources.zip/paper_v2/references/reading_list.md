# 核心文献与后续检索计划

核验日期：2026-10-11。本轮已读取下列原始论文页面／官方出版记录；尚未完成系统性检索及逐篇全文方法复核。

## 已核对的起点文献

| 文献 | 在本论文中的作用 | 原始来源 |
|---|---|---|
| Jain & Wallace, 2019. Attention is not Explanation | 注意力与梯度归因／输出的关系；不能直接外推到全部模型 | [ACL Anthology](https://aclanthology.org/N19-1357/) |
| Wiegreffe & Pinter, 2019. Attention is not not Explanation | 解释定义、随机种子与控制设计；用于平衡相关工作 | [ACL Anthology](https://aclanthology.org/D19-1002/) |
| Jain, Mohammadi & Wallace, 2019. An Analysis of Attention over Clinical Notes for Predictive Tasks | 已有生物医学注意力诊断研究；防止误称首次医学扩展 | [ACL Anthology](https://aclanthology.org/W19-1902/) |
| Sundararajan, Taly & Yan, 2017. Axiomatic Attribution for Deep Networks | Integrated Gradients 定义及公理；为参考输入、路径和 completeness 核验提供基础 | [PMLR](https://proceedings.mlr.press/v70/sundararajan17a.html) |
| Adebayo et al., 2018. Sanity Checks for Saliency Maps | 参数随机化等解释检查的依据 | [NeurIPS](https://proceedings.neurips.cc/paper/2018/hash/294a8ed24b1ad22ec2e7efea049b8737-Abstract.html) |
| Liu et al., 2020. DeepCDR: a hybrid graph convolutional network for predicting cancer drug response | 原始方法、输入与评价；核对项目适配和官方模型的差异 | [Bioinformatics](https://academic.oup.com/bioinformatics/article/36/Supplement_2/i911/6055929)、[作者代码](https://github.com/kimmo1019/DeepCDR) |
| Bernett et al., 2026. Critical evaluation of drug response prediction models with DrEval | 药物响应任务划分、基线、组内指标、实体依赖和消融设计 | [Nature Communications](https://www.nature.com/articles/s41467-026-72903-w) |

DrEval 原始页面记录发表日期为 2026-05-12。其存在意味着“严格评估药物响应模型”本身已有充分先例；本论文应以具体的联合诊断问题和可辨识的对照定位贡献。不能将本轮有限检索当成查新结论。

## 后续检索主题

1. 药物响应中的 PPI／DTI 图先验：是否与无生物网络、随机网络和容量匹配模型比较。
2. 图自监督／边重建预训练：预训练任务与连续响应预测迁移的关系。
3. 药物条件化注意力：是否评价输入归因、分支贡献、注意力干预和样本特异性。
4. 药物响应评价：随机配对、药物／细胞系／组织留出、外部队列、药物均值效应。
5. 生物解释评价：归因忠实度、靶点恢复、通路富集及其不同证据含义。

优先使用论文出版页面、会议论文集、作者预印本与作者代码。对预印本记录版本与同行评审状态；不依据二手总结填充实验事实。

## 每篇文献需要记录的字段

- 准确题目、作者、年份、DOI／原始 URL、发表状态。
- 数据版本、响应指标、输入与实体覆盖。
- 数据划分、预处理拟合范围、测试实体的先验可用性。
- 主要模型、有效控制、随机种子和基线调参规则。
- 是否区分推理扰动与重新训练消融。
- 是否区分解释一致性、输出忠实度和生物学合理性。
- 与本论文三个问题的重合、差异及可验证缺口。

完成文献矩阵后再锁定 Introduction 的创新性表述和目标期刊；生成共享 `references.bib` 时从核验过的出版信息导入，逐条检查引用键与元数据。
