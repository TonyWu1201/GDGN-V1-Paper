# B4 诊断初稿：文献核验与主题综合

核验日期：2026-10-12。本文献包与 `shared/references.bib` 配套，共 24 篇原始研究及资源论文（22 篇主题文献，2 篇图来源资源论文）。检索目标是为三个问题建立足够的概念和方法背景：注意力与输入归因的关系、图预训练的迁移条件、生物关系图的实际作用。

这是一份**叙述性专题综述的定向文献包**。检索结合论文题名、方法名与上述主题，通过出版方、正式会议论文集、作者公开论文及作者代码核验。未预登记数据库检索式、筛选流程或穷尽性标准，因此正文应称 narrative review 或 focused review，不使用 systematic review、PRISMA 或 meta-analysis。论文自身的 B4 数值来自项目档案，以下文献只支持外部背景与方法论。

## 1. 数据与药物响应模型

| 引用键 | 核验后的书目信息／原始来源 | 建议引用支持的具体英文句子 | 本文使用范围 |
|---|---|---|---|
| `gdsc2013` | Yang et al., 2013, *Nucleic Acids Research* 41(D1):D955–D961. DOI [10.1093/nar/gks1111](https://academic.oup.com/nar/article/41/D1/D955/1059448). 在线先行发表于 2012-11-22，正式卷期为 2013。 | GDSC links cancer cell line drug-sensitivity measurements to molecular profiles, providing a resource for pharmacogenomic biomarker discovery. | 数据资源背景。文中 138 药物／近 700 细胞系对应当时版本，不能直接作为本项目规模或最新规模。 |
| `ccle2012` | Barretina, Caponigro, Stransky et al., 2012, *Nature* 483:603–607. DOI [10.1038/nature11003](https://www.nature.com/articles/nature11003). 作者稿：[PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC3320027/). | The CCLE established a molecularly characterized cancer cell line resource for studying predictors of anticancer drug sensitivity. | CCLE 是特征与药理资源；本项目使用哪些版本和组学，要依本地来源记录说明。 |
| `iorio2016` | Iorio, Knijnenburg, Vis et al., 2016, *Cell* 166(3):740–754. DOI [10.1016/j.cell.2016.06.017](https://pmc.ncbi.nlm.nih.gov/articles/PMC4967469/). | Large-scale pharmacogenomic profiling relates genomic alterations and tissue context to drug response across cancer cell lines. | 支持多组学与组织背景的研究动机；不是 B4 的临床有效性证据。 |
| `string2023` | Szklarczyk et al., 2023, *Nucleic Acids Research* 51(D1):D638–D646. DOI [10.1093/nar/gkac1000](https://academic.oup.com/nar/article/51/D1/D638/6825349). [作者公开全文](https://www.bork.embl.de/publication/pdf/36370105.pdf). 正式卷期 2023，在线先行 2022；该论文介绍 STRING v12.0。 | STRING integrates physical protein interactions and functional associations into scored protein-association networks. | 解释 supplied preprocessing scripts 中 `9606.protein.links.v12.0.txt` 的资源语义；不能把全部 STRING 边称为直接物理结合。阈值和数据子图取自本地代码，不由资源论文推定。 |
| `dgidb2024` | Cannon et al., 2024, *Nucleic Acids Research* 52(D1):D1227–D1235. DOI [10.1093/nar/gkad1040](https://academic.oup.com/nar/article/52/D1/D1227/7416371). [作者机构原文记录](https://digitalcommons.wustl.edu/oa_4/2839/). 正式卷期 2024，在线先行 2023。 | DGIdb aggregates drug–gene interaction claims from multiple sources, supporting annotation-based hypothesis generation. | 本条用于说明 DGIdb 资源性质。论文题名的 5.0 不代表本地归档下载版本；本地 release 未确定，正文不指定。项目未按直接结合的 interaction type 筛选，DTI 应作为操作性标签使用。 |
| `moli2019` | Sharifi-Noghabi, Zolotareva, Collins and Ester, 2019, *Bioinformatics* 35(14):i501–i509. DOI [10.1093/bioinformatics/btz318](https://academic.oup.com/bioinformatics/article/35/14/i501/5529255). | MOLI learns modality-specific representations of expression, mutation and copy-number data, and combines classification and triplet objectives for drug-response prediction. | 原文预测二元响应，并进行 PDX／患者外部验证。可比较融合策略，不把其分类指标与 B4 连续 LN_IC50 回归直接排名。名称采用原文 late integration；结构实际在编码表征层拼接。 |
| `deepcdr2020` | Qiao Liu, Zhiqiang Hu, Rui Jiang and Mu Zhou, 2020, *Bioinformatics* 36(Supplement_2):i911–i918. DOI [10.1093/bioinformatics/btaa822](https://academic.oup.com/bioinformatics/article/36/Supplement_2/i911/6055929). 已读取[作者公开全文](https://kimmo1019.github.io/publication/2020-eccb-liu/2020-ECCB-Liu.pdf)及[作者代码](https://github.com/kimmo1019/DeepCDR). | DeepCDR combines molecular graph convolutions with subnetworks for genomic mutation, expression and DNA methylation, followed by joint prediction. | 原文包含回归及分类设置。它的核心图是药物原子—化学键图；不能用它证明 PPI／DTI 图拓扑收益。项目适配 baseline 的名称应与官方方法区分。 |
| `graphdrp2022` | Tuan Nguyen, Giang T. T. Nguyen, Thin Nguyen and Duc-Hau Le, 2022, *IEEE/ACM Transactions on Computational Biology and Bioinformatics* 19(1):146–154. DOI [10.1109/TCBB.2021.3060430](https://doi.org/10.1109/TCBB.2021.3060430). 核对了[作者机构记录](https://dro.deakin.edu.au/articles/journal_contribution/Graph_Convolutional_Networks_for_Drug_Response_Prediction/20673588)与[作者代码](https://github.com/hauldhut/GraphDRP). | GraphDRP encodes drugs as molecular graphs and cell lines as genomic-aberration vectors before predicting pairwise response values. | 正式期刊年份为 2022，DOI 中的 2021 不是应当机械套用的卷期年份。分子图收益与生物关系网络收益是不同问题。作者公开代码支持 mixed、blind-drug 与 blind-cell 数据处理模式。 |
| `graphcdr2022` | Xuan Liu, Congzhi Song, Feng Huang, Haitao Fu, Wenjie Xiao and Wen Zhang, 2022, *Briefings in Bioinformatics* 23(1):bbab457. DOI [10.1093/bib/bbab457](https://academic.oup.com/bib/article/23/1/bbab457/6415314). 在线发表于 2021-11-01。 | GraphCDR combines biochemical representations with a drug–cell response graph and uses contrastive learning as a concurrent regularizer. | 图的边由敏感／耐药响应定义，输出为响应分类；它不是 GDGN 的 PPI／DTI 图，也不是 staged 边重建预训练。本文把它作为任务相关的对比目标实例。 |
| `paccmann2019` | Matteo Manica, Ali Oskooei, Jannis Born, Vigneshwari Subramanian, Julio Sáez-Rodríguez and María Rodríguez Martínez, 2019, *Molecular Pharmaceutics* 16(12):4797–4806. DOI [10.1021/acs.molpharmaceut.9b00520](https://pubs.acs.org/doi/10.1021/acs.molpharmaceut.9b00520). 已读取[作者预印本](https://arxiv.org/abs/1904.11223). | PaccMann combines SMILES, gene expression and interaction-network information, using gene-expression context to attend to molecular sequence features. | 精确引用期刊题名 Toward Explainable…，不是把 2018 workshop 版本或 2020 Web 服务论文混作同一条。原文 Fig.2C／§2.3 的上下文注意力是 expression → SMILES tokens，gene attention 为 expression 的 dense softmax；不把它写成 drug-query → gene attention。富集与案例属于生物学合理性证据。 |
| `drugcell2020` | Brent M. Kuenzi, Jisoo Park, Samson H. Fong, Kyle S. Sanchez, John Lee, Jason F. Kreisberg, Jianzhu Ma and Trey Ideker, 2020, *Cancer Cell* 38(5):672–684.e6. DOI [10.1016/j.ccell.2020.09.014](https://pmc.ncbi.nlm.nih.gov/articles/PMC7737474/). 读取了[作者公开全文](https://idekerlab.ucsd.edu/wp-content/uploads/2020/10/Kuenzi-Park_CancerCell2020.pdf). | DrugCell organizes genotype representations through a hierarchy of cellular subsystems and connects model-derived mechanisms to experimental tests of drug combinations. | 作为结构化可解释模型及实验验证层次的实例。其机制与协同验证属于该原始研究，不能借作 B4 的实验结论。 |
| `drpreter2022` | Jihye Shin, Yinhua Piao, Dongmin Bang, Sun Kim and Kyuri Jo, 2022, *International Journal of Molecular Sciences* 23(22):13919. DOI [10.3390/ijms232213919](https://www.mdpi.com/1422-0067/23/22/13919). | DRPreter encodes pathway-specific gene-network subgraphs and drug molecules, then uses a type-aware transformer to model pathway–drug relations. | 是与 GDGN 图 + 注意力主题密切相关的前作。其原文包括基因和通路案例；本文提出的是对解释证据进行分层，并非声称此类解释从未被研究。 |

## 2. 注意力、输入归因与解释检验

| 引用键 | 核验后的书目信息／原始来源 | 建议引用支持的具体英文句子 | 本文使用范围 |
|---|---|---|---|
| `jain2019` | Sarthak Jain and Byron C. Wallace, 2019, NAACL-HLT, pp.3543–3556. DOI [10.18653/v1/N19-1357](https://aclanthology.org/N19-1357/). | In the studied NLP models, attention rankings often disagreed with gradient-based importance, and substantially different attention distributions could produce similar predictions. | 结果限定于原文模型和任务。用于说明相关性及注意力干预的必要性，不写成所有注意力机制的否定定理。 |
| `wiegreffe2019` | Sarah Wiegreffe and Yuval Pinter, 2019, EMNLP-IJCNLP, pp.11–20. DOI [10.18653/v1/D19-1002](https://aclanthology.org/D19-1002/). | Evaluating attention as explanation requires a stated explanatory target and model-aware controls, including uniform attention and calibration across random seeds. | 与 Jain & Wallace 配对引用，保留讨论的条件性。作者提出四类诊断，其中均匀基线、种子方差、冻结模型和端到端对抗注意力各有不同作用。 |
| `clinicalattn2019` | Sarthak Jain, Ramin Mohammadi and Byron C. Wallace, 2019, ClinicalNLP, pp.15–21. DOI [10.18653/v1/W19-1902](https://aclanthology.org/W19-1902/). | Clinical-note prediction already provides a biomedical example in which attention improves prediction while its explanatory role requires separate assessment. | 已有医学领域延伸，故 B4 不能自称首次把 attention-is-not-explanation 问题带入生物医学。原文摘要与正文任务计数存在口径差异，正文无需复述计数。 |
| `serrano2019` | Sofia Serrano and Noah A. Smith, 2019, ACL, pp.2931–2951. DOI [10.18653/v1/P19-1282](https://aclanthology.org/P19-1282/). | Intervening on attention-weighted representations offers a direct way to assess whether attention magnitudes track their contribution to model outputs. | 原文是已训练文本分类模型中的注意力／表征删除。用于启发固定 value 的注意力干预；迁移到组学时要描述具体操作。 |
| `sundararajan2017` | Mukund Sundararajan, Ankur Taly and Qiqi Yan, 2017, ICML, PMLR 70:3319–3328. [正式论文集](https://proceedings.mlr.press/v70/sundararajan17a.html). 正式记录未给 DOI，BibTeX 保留 URL。 | Integrated Gradients attributes a prediction relative to a reference input by integrating input gradients along a path, with completeness linking the attribution sum to the output difference. | IG 需要明确输入、参考点、路径和数值积分。若函数还依赖固定分支／派生通路，completeness 仅针对明确的参考函数。它是比较方法，不是真实生物效应标签。 |
| `adebayo2018` | Julius Adebayo, Justin Gilmer, Michael Muelly, Ian Goodfellow, Moritz Hardt and Been Kim, 2018, NeurIPS 31. [正式论文集](https://proceedings.neurips.cc/paper/2018/hash/294a8ed24b1ad22ec2e7efea049b8737-Abstract.html). | Model-parameter and label-randomization tests assess whether an attribution method reflects what the model learned. | 原始主要实证对象是图像。其随机化思想可用于本项目审计，但本初稿没有执行就不能写“passed sanity checks”。 |
| `gnnexplainer2019` | Zhitao Ying, Dylan Bourgeois, Jiaxuan You, Marinka Zitnik and Jure Leskovec, 2019, NeurIPS 32. [正式论文集](https://proceedings.neurips.cc/paper_files/paper/2019/hash/d80b7040b773199015de6d3b4293c8ff-Abstract.html). | GNNExplainer searches for compact subgraphs and node-feature subsets that preserve information about a graph model's prediction. | 支持将结构解释与特征解释分别处理。正文不声称已运行 GNNExplainer；也不能把子图选择自动解读为因果生物机制。正式元数据第一作者为 Zhitao Ying，PDF 署名 Rex Ying。 |
| `graphattribution2020` | Benjamin Sanchez-Lengeling, Jennifer Wei, Brian Lee, Emily Reif, Peter Y. Wang, Wesley Wei Qian, Kevin McCloskey, Lucy Colwell and Alexander Wiltschko, 2020, NeurIPS 33. [正式论文集](https://proceedings.neurips.cc/paper_files/paper/2020/hash/417fbbf2e9d5a28a855a11894b2e795a-Abstract.html). | Graph attribution can be assessed along distinct dimensions of accuracy, stability, faithfulness and consistency using tasks with computable ground truth. | 原文定量基准有可计算真值，本项目靶点列表不是完整真值。由此把排序一致性、预测依赖和生物学合理性分开论述。 |

## 3. 图预训练与评价设计

| 引用键 | 核验后的书目信息／原始来源 | 建议引用支持的具体英文句子 | 本文使用范围 |
|---|---|---|---|
| `hu2020` | Weihua Hu, Bowen Liu, Joseph Gomes, Marinka Zitnik, Percy Liang, Vijay Pande and Jure Leskovec, 2020, ICLR. [正式记录](https://openreview.net/forum?id=HJlWWJSFDH)；已读取[作者论文版本](https://arxiv.org/abs/1905.12265). | Graph pretraining can improve transfer, while the choice of pretraining level and objective can also produce negative transfer. | 原始任务含分子性质与蛋白功能分类；其负迁移发现建立研究动机，不证明 GDGN 边扰动目标必然与 LN_IC50 不对齐。2019 是预印本首版年，正式会议为 2020。 |
| `graphcl2020` | Yuning You, Tianlong Chen, Yongduo Sui, Ting Chen, Zhangyang Wang and Yang Shen, 2020, NeurIPS 33. [正式论文集](https://proceedings.neurips.cc/paper/2020/hash/3fe230348e9a12c13120749e3f9fa4cd-Abstract.html). | GraphCL learns representations by contrasting augmented graph views and investigates how augmentation choices affect downstream transfer. | 边扰动在对比视图中与在边重建目标中具有不同含义。引用用于区分目标设计，不能把其实验指标借给本项目。 |
| `graphmae2022` | Zhenyu Hou, Xiao Liu, Yukuo Cen, Yuxiao Dong, Hongxia Yang, Chunjie Wang and Jie Tang, 2022, KDD, pp.594–604. DOI [10.1145/3534678.3539321](https://doi.org/10.1145/3534678.3539321). 已读取[作者全文](https://keg.cs.tsinghua.edu.cn/jietang/publications/KDD22-Hou-et-al-GraphMAE.pdf)及[作者代码](https://github.com/THUDM/GraphMAE). | GraphMAE studies generative graph pretraining through masked feature reconstruction and a scaled cosine reconstruction loss. | 它强调特征重建而非简单结构重建。本文可用它展示自监督目标的多样性；新初稿无需复现其训练。 |
| `dreval2026` | Judith Bernett, Pascal Iversen, Mario Picciani, Mathias Wilhelm, Katharina Baum and Markus List, 2026, *Nature Communications* 17:4238. DOI [10.1038/s41467-026-72903-w](https://www.nature.com/articles/s41467-026-72903-w). 发表日期 2026-05-12；核对了[原文全文索引](https://pmc.ncbi.nlm.nih.gov/articles/PMC13168506/). | DrEval separates pair, cell-line, tissue and drug holdouts, and evaluates predictive performance beyond drug and cell-line mean effects. | 其 benchmark 中均值效应强、复杂模型优势有限，属于其测试条件。B4 未在 DrEval 中被评测；本文不能借此断言 B4 完全依赖药物均值。适合引用其评估协议，避免把本稿包装为首个严格评估研究。 |

## 4. 可直接改写为正文的英文综合

下面四段均为综合性原创改写；引文键对应共享 BibTeX。建议根据文章篇幅整合使用，避免与相关工作表重复描述每篇方法。

### Paragraph A: representations and graph semantics

Large-scale pharmacogenomic resources connect molecular characterization of cancer cell lines with measured drug responses, establishing the empirical basis for data-driven response prediction \citep{gdsc2013,ccle2012,iorio2016}. Models differ substantially in what they encode and what their graphs represent. MOLI learns separate representations of mutation, expression and copy-number data before combining them for response classification \citep{moli2019}. DeepCDR couples molecular graph convolutions to multi-omics subnetworks, whereas GraphDRP combines molecular graph representations with genomic-aberration features \citep{deepcdr2020,graphdrp2022}. These molecular graphs describe atoms and chemical bonds. DRPreter instead introduces pathway-specific gene-network subgraphs, and GraphCDR additionally represents observed drug–cell responses as edges \citep{drpreter2022,graphcdr2022}. This distinction gives graph-based response prediction a precise vocabulary: molecular structure, biological relations and observed responses contribute different information, motivating controls that match the graph's intended role.

### Paragraph B: attention as an empirical explanatory hypothesis

Attention offers a convenient interface for inspecting multimodal predictors. PaccMann uses gene-expression context to attend to chemical sequence features, and DRPreter uses pathway–drug interactions to organize biological interpretation \citep{paccmann2019,drpreter2022}. The explanatory meaning of these weights is an empirical question about a specified model. Jain and Wallace found disagreements between attention and gradient-based rankings in the NLP architectures they studied; Wiegreffe and Pinter emphasized definitions, random-seed variation and model-aware controls \citep{jain2019,wiegreffe2019}. Clinical-note research had already separated attention's predictive contribution from its explanatory role \citep{clinicalattn2019}. For drug response, the resulting agenda is concrete: compare rankings, intervene on the attention mechanism, and test the effect of the selected molecular inputs. Representation erasure provides one precedent for examining output dependence \citep{serrano2019}.

### Paragraph C: complementary explanation criteria

Input attribution and biological coherence answer complementary questions. Integrated Gradients allocates a model's output difference relative to a specified reference input, making the reference, path and numerical approximation part of the explanation protocol \citep{sundararajan2017}. Randomization checks assess whether saliency depends on learned model parameters and training labels \citep{adebayo2018}. At graph level, GNNExplainer targets compact structural and feature subsets, while graph-attribution benchmarks separate accuracy, stability, faithfulness and consistency \citep{gnnexplainer2019,graphattribution2020}. DrugCell illustrates an additional evidential level by linking model-derived subsystem mechanisms to experimental combination tests \citep{drugcell2020}. This hierarchy supports a clear reporting practice: describe agreement between methods, dependence of predictions on interventions, and coherence with known biology as distinct findings, each evaluated with its corresponding controls.

### Paragraph D: transfer and evaluation

Graph pretraining is best understood through the relationship between its auxiliary objective and the downstream task. Hu and colleagues documented both successful transfer and negative transfer under different pretraining strategies \citep{hu2020}. GraphCL contrasts augmented graph views, GraphMAE reconstructs masked node features, and GraphCDR incorporates a response-informed contrastive regularizer into joint training \citep{graphcl2020,graphmae2022,graphcdr2022}. These alternatives motivate explicit specification of the pretraining signal, trainable modules and fine-tuning budget in a drug-response study. Evaluation provides an equally important part of the interpretation. DrEval distinguishes holdout targets and measures performance beyond drug and cell-line mean effects \citep{dreval2026}. A diagnostic account of GDGN can therefore organize its evidence around three questions: which information an explanation measures, which objective a pretrained representation serves, and which graph-dependent signal contributes under the stated prediction protocol.

## 5. 本稿定位与写作决策

1. **推荐定位。** A focused narrative review with a retrospective diagnostic case study。综述提出三条检验路线，B4 档案提供实例；初稿不是完成全部实验的强因果诊断论文。
2. **可主张的价值。** 把解释一致性、预训练迁移和图依赖置于同一模型家族的证据链，给出明确的数据与对照定义。用“we organize / examine / synthesize / illustrate”比未经查新的“first / comprehensive proof”准确。
3. **图语义在全文保持一致。** GDGN 的 biological relation graph 使用档案中的 PPI／DTI 操作性名称，具体来源为 STRING 蛋白关联与 DGIdb 药物—基因记录；其中既有功能关联，也有并非直接结合的药物—基因类型。药物 molecular graph 是原子／键；“without PPI/DTI”不应写成“without graphs”。GraphCDR 的 response graph 又是第三种对象。
4. **历史数据的角色。** A1/A4 同时改变主药物嵌入，适合说明配置混杂；固定检查点图替换适合说明模型依赖；注意力与 IG 的低相关适合说明排序不一致。综述直接解释这些证据各自回答什么，将尚未完成的受控重训练集中到一处展望。
5. **控制限制表述的位置。** 方法／证据边界小节交代完整限定，讨论末尾集中列必要扩展。相关工作段以具体方法及其所解决的问题收束，结果段以观察和含义收束，避免每段重复“however, remains to be validated”。

## 6. 引用与元数据核验说明

- 共享 BibTeX 共 24 个独立键。对于 CCLE 和 Iorio 的大型作者组，使用前三位作者 + `and others`，表示明确截短，不补造完整作者列表；其余条目保留已核对的完整作者名单。
- GDSC、GraphDRP、GraphCDR、Hu 等以正式卷期／会议年份作 bibliography 年份；线上先行年份在本记录中单独说明。
- ACL、PMLR 与 NeurIPS 引用依其正式论文集元数据。NeurIPS 原文未给 DOI 的条目仅列官方 URL。
- 无全文可读的出版入口以作者公开版本／作者代码补充，不从二手综述反推模型细节。GraphDRP 的正式元数据与作者机构记录相符；GraphCDR 方法和分类设置经出版方全文检索核验。
- 本稿不需要转引二手综述。文献表中不列未经本文实际核验的扩展方法，也不把 2026 年论文错写为未来工作。
- 本综合使用改写，未粘贴原论文摘要或大段原文。各单篇描述应保持简洁；最终论文优先引用研究设计与概念，跨论文数值排行榜需要另行统一协议。

## 7. 图来源与本地预处理语义（2026-10-12 补充核验）

这里只根据 supplied preprocessing scripts 和 supplied annotation files 解释当前可见处理规则，不把代码文件自动认定为每个历史 checkpoint 的完整、逐边可追溯输入。

| 项目 | 本地证据 | 可写入正文的准确含义 |
|---|---|---|
| STRING 来源与筛选 | `program/preprocess/ppi_filter.py` 指向 `9606.protein.links.v12.0.txt` 和同版 aliases 文件；`SCORE_THRESHOLD = 700`，筛选表达式为 `chunk["combined_score"] > SCORE_THRESHOLD`。 | STRING v12.0 protein-association records were filtered at raw `combined_score > 700`. 严格大于，非大于等于；分数列为原始 combined_score。 |
| STRING 标识与范围 | aliases 的 `source == "Ensembl_HGNC_symbol"` 用于 protein → symbol；去未映射和自环；以 DGIdb 涉及的基因作起点，`MAX_HOP = 1`。 | 基因映射及子图为项目处理，资源自身并不限定到 8,412 个核心基因；后续核心基因交集需单独说明。 |
| DGIdb 筛选阈值 | `program/preprocess/filter_dgi.py` 先删除缺失 `interaction_score`；`scores = df["interaction_score"]`；`score_threshold = 0.175`；`mask = scores > score_threshold`。 | 原始 `interaction_score > 0.175`，不是归一化 `score_norm > 0.175`。 |
| DGIdb 权重 | 所有非缺失原始 score 先 `log1p`，再以筛选前的 min/max 进行缩放；阈值筛选后保存 `score_norm`；CID／gene 重复对取最大值。 | 阈值使用 raw score，保存的表示权重使用 log/min-max score；这些 score 不等于测定的结合强度或 LN_IC50。 |
| DGIdb 关系类型 | 代码保留 `interaction_score` 合格、CID 可映射的记录，没有按 `interaction_type` 筛为直接物理结合。 | 解释结果与 retained drug–gene annotation sets 的重叠，体现注释恢复；可保留 DTI 作为实现标签，并首次定义其范围。 |
| DGIdb 版本 | 原始目录含 `categories.tsv`、`drugs.tsv`、`genes.tsv`、`interactions.tsv`；header 的 `interaction_source_db_name`／`interaction_source_db_version` 记录贡献来源及其版本，未见全库 release manifest。 | 本地下载 release 不能确定。引用 `dgidb2024` 描述资源时，不声明本地使用 DGIdb 5.0，也不拿 DTC 等来源版本字段代替 DGIdb release。 |
| 当前覆盖重建 | 本稿 reanalysis 以 supplied filtered interaction CSV、CID map 和 core gene list 交集计算 7／11 与 1,124；没有逐边核对训练时 graph tensor。 | 用 reconstructed represented annotation coverage／supplied annotation files，7 与 11 的区别是映射层级；不等于“药物真实无靶点”或已证实某历史图恰有 11 个零度药物。 |

可合并到正文的方法句：

> In the supplied preprocessing scripts, the operational PPI relation is derived from STRING v12.0 protein-association records using raw `combined_score > 700`, while the operational DTI relation retains DGIdb drug–gene records with raw `interaction_score > 0.175` after compound mapping. STRING includes physical and functional associations, and the retained DGIdb records are broader than direct binding evidence \citep{string2023,dgidb2024}.

该段用资源文献支持数据库性质，用本地代码支持阈值；两类出处的作用清楚分开。
