# paper_v2 叙事与科学表述审阅

审阅依据：[anti-defensive-writing/SKILL.md](C:/Users/13249/.codex/skills/anti-defensive-writing/SKILL.md)。审阅对象：`manuscript_en/main.tex`，SHA256 `6FD32237E026512057F624A933E52E09142667CA51E427F6119CD7C2D33B83AF`，2026-10-12。本轮只读正文，沿用 v1 的数值及 24 篇原始文献核验，没有联网扩展题材、修改数据或执行训练。

## 总体判断

v2 已形成成立的主线：**通过信息路线与实验比较配对，解释同一模型家族对生物关系输入的不同依赖。** 摘要第 3 句给出框架，第 5 句给出 A4／B4 的核心数值；案例以图敏感性开场，预测排行榜移到上下文位置。最强证据已经承担主结果，文章摆脱了按开发阶段汇报成功与失败的结构。

科学边界整体准确：固定 checkpoint 敏感性与重训练拓扑收益分别定义；IG 是指定函数的条件归因，未作为生物学真值；A1／A4 明确是同时改变初始化、信息访问和 head 容量的配置比较；7／11 是注释重建计数。PaccMann 的注意力方向、GraphCDR 的响应图与共同训练目标、MOLI 的分类设置、STRING／DGIdb 的资源语义延续了 v1 的修正。没有发现需要增加文献或新增训练才能修复的论断。

以下四项足以完成本轮，前两项优先。

## 1. 将引言的贡献与核心发现提前到首段

**位置：** Introduction 第 1–3 段，原第 16–22 行。

摘要已通过“前五句”检查；引言前五句仍在交代背景和模型发展，框架到第 3 段才出现，A4／B4 到第 4 段才出现。现有材料可以直接重排，无需再扩写背景。

**建议：** 首段按“问题 → 现有评价未区分信息路线 → 本文框架 → A4／B4 主结果”组织，GDSC／CCLE 及代表模型合并到下一段。可采用以下开场骨架：

> Biological priors enter cancer drug response models through connectivity, auxiliary learning and conditional readout. Understanding their contribution requires linking each route to the comparison that reveals its role. This review develops that diagnostic framework and illustrates it with GDGN records through B4. Under fixed-checkpoint PPI self-loop replacement, A4 and B4 show PCC changes of −0.0007 and −0.1458, respectively. The contrast anchors a joint analysis of relational dependence, attention readout and conditional input attribution.

这段只使用稿内现有信息。框架与结果进入首段后，现第 3–5 段合并即可，避免把同一贡献再宣布一次。

## 2. 收紧 Discussion 的因果小标题，并以核心观察开篇

**位置：** `Architecture determines how a prior is used`，原第 216 行及紧随的首段。

“determines”比结果支持的力度强。A4／B4 同时改变结构、容量和完整训练配置；固定参数干预支持这两个已拟合系统的 relational-dependence profiles，不隔离“架构本身导致该差异”的因果效应。

**建议：** 小标题改为 **Architecture-specific profiles of relational dependence**，或 **How fitted architectures use relational inputs**。Discussion 首段直接从“B4 的显著关系敏感性与反复出现的 attention 排序并存”展开，再连接 framework。现在的 connectivity／initialization／readout 总览已在前文解释多次，可压缩为一句。

正文中的 “architecture-specific” 和 “in the examined model family”可以保留；无需增加新的否定段落。这是把贡献精确地命名，保持主结果的力度。

## 3. 在摘要中把“路线名称”改为“待评估的主张”

**位置：** 摘要第 3 句：`connects three claims ... attention as a readout, pretraining as transfer, and graph structure as a relational prior`。

后三项目前是路线定义，不是需要证据回答的主张。框架的价值在于连接 claim 与 comparison，措辞应直接展示它回答什么。

**建议替换：**

> This narrative review develops a diagnostic framework that links claims about what attention explains, whether pretraining transfers, and what biological topology contributes to their corresponding comparisons.

这使摘要与正文三种 contrast 更紧密对应，也清楚表明框架的综合贡献。A4／B4 数值继续作为第一个实证结果。

## 4. 删除少量重复的自我评价句，保留具体定义

以下句子没有新增结果或条件，可以直接删除或与前句合并：

- §2.1 末句 `The distinction between graph semantics and computational role makes cross-method synthesis more informative than a shared graph-based label.` 前文已展示该区分的具体作用。
- §4.3 末句 `Rank agreement, output dependence and annotation recovery each contribute a defined piece of evidence.` §3 已给出完整定义。
- §4.5 `All rows provide the descriptive predictive context ...` 段首已说明 predictive context。
- Scope and extensions 末句 `These definitions support the diagnostic conclusions presented here.` 保留 single runs、development-selected cases、两组配置比较的准确条件即可。
- Appendix 中 `These metadata delimit the reanalysis ...` 前句列出的未保存记录已表达完整来源边界。

这些精简针对重复的写作说明，不删掉具体方法：固定参数、self-loops／placeholder、fwd／rev 分别随机化、conditional IG 与 L2 ranking 的区别、stored Spearman scalar、案例选择、原始 score 阈值、DGIdb release 未确定，以及 coverage 来自 supplied files。这些信息赋予结果确定含义，应保留在现有方法／附录位置。

## 审阅结论

可以在完成上述局部调整后进入中英同步与排版检查。无需继续泛化标题、扩展文献版图或补造机制解释；当前最值得读者记住的结果是 **同一类关系干预在 A4 与 B4 中产生 sharply different sensitivity profiles，而图依赖与 attention–attribution agreement 是两个分别可检验的属性**。
