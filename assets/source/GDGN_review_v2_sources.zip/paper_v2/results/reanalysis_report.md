# Archived GDGN B4-era evidence reanalysis

Date: 2026-10-12. This script reads archived reports and explanatory records. It performs no training, inference, or new IG computation.

## Random-pair test performance

Eight archived seed-42 configurations each report 6,655 test pairs. The report precision is four decimals; split tensor membership was not rechecked.

| Model | PCC | RMSE | MAE | Pretraining | Main drug embedding |
|---|---:|---:|---:|---|---|
| A0 | 0.9055 | 1.2587 | 0.9138 | True | False |
| A1 | 0.9162 | 1.1925 | 0.8882 | True | True |
| A4 | 0.9191 | 1.1533 | 0.8564 | False | False |
| B1 | 0.9232 | 1.1278 | 0.8387 | False | False |
| B3 | 0.9175 | 1.1760 | 0.8649 | False | False |
| B4 | 0.9354 | 1.0389 | 0.7735 | False | False |
| Flatten | 0.9378 | 1.0191 | 0.7549 | False | None |
| CDR adapter | 0.9215 | 1.1511 | 0.8396 | False | None |

A1 and A4 change both pretraining and the main drug embedding. Their observed difference is a comparison of configurations, not an isolated pretraining effect.

## Attention, IG, and target coverage

The ten selected cases cover five drugs. Imported rank correlations average -0.000442738002, with range [-0.008458427047, 0.012438615097]. Full attention vectors are absent, so these rho values cannot be independently recalculated here.

The mean top-20 Jaccard is 0.919183554 for attention and 0.024974592 for saved IG. These are 45 overlapping case pairs, reported descriptively rather than as independent statistical observations.

The most common ordered attention top-5 signature occurs in 8/10 cases: LIG3, CASP14, SERPINA1, ABL2, ACKR3.

All ten reconstructed IG top-20 names exactly match the saved top-20 names under the current core gene order. This checks the selected gene mapping, not the full historical input/checkpoint correspondence.

Six cases (three drugs) have measurable filtered-CSV targets; four cases are N/A. IG top-20 and attention top-20 each have zero hits in the six eligible cases. The uniform top-20 random expected total is 0.028530670471; a zero-hit outcome therefore has little discriminatory power in this small target set.

## Fixed-checkpoint graph perturbations

The first A4 original record is the reference; its duplicate differs only at numerical precision and is not a replicate. Delta means perturbed minus original.

| Mode | A4 delta PCC | B4 delta PCC | A4 RMSE | B4 RMSE |
|---|---:|---:|---:|---:|
| original | 0.000000000 | 0.000000000 | 1.153252 | 1.038872 |
| permute_ppi | -0.000203105 | -0.082899765 | 1.155207 | 2.219347 |
| permute_dti | -0.000402586 | -0.034091668 | 1.156568 | 1.560156 |
| permute_both | -0.000181582 | -0.051378416 | 1.154625 | 2.033367 |
| remove_ppi | -0.000699974 | -0.145801120 | 1.158873 | 2.479556 |
| remove_dti | -0.000892571 | -0.070218855 | 1.163061 | 2.356036 |
| remove_both | -0.000829157 | -0.148198685 | 1.162268 | 2.490553 |

PPI removal replaces PPI with self-loops; DTI removal keeps a dummy edge. Historical random rewiring preserves source lists and edge counts but not target degrees, and opposite relations are generated separately. These values measure fixed-checkpoint sensitivity under that implementation.

## Reconstructed DTI coverage

The archived seven-drug list exactly matches zero filtered-CSV targets among 184 mapped drugs: [2, 12, 25, 41, 47, 67, 69]. Intersecting targets with the core gene universe yields 11 zero-coverage drugs: [2, 12, 25, 41, 47, 67, 69, 121, 158, 168, 172].

The four additional drug indices [121, 158, 168, 172] have only out-of-core target symbols (F7R; FRA9D; GLC# and GLC1B; GLC3B). The reconstructed core universe contains 1,124 unique mapped drug-gene pairs, matching the edge count stated in the perturbation logs. Graph tensors were not loaded, so the wording remains reconstructed coverage.

No DTI means absent from this mapping and filtering procedure; the manuscript does not equate it with absence of pharmacological targets.

## Split-count provenance

Archived split_stats.txt records 66,543 observed pairs: 53,233 train, 6,655 validation, 6,655 test. Training evaluation rows may use fewer pairs due to batching/drop_last. These counts are transcribed from text; split tensor membership was not verified in this run.

## Outputs and reproducibility

The executable script, source hashes, machine-readable summaries, CSV tables, and three vector-PDF figures are included. PDF generation uses ReportLab invariant mode. No current defense presentation, defense-stage case study, later model, or archived cold-start label is used.
