"""Create labelled two-page contact sheets of Poppler-rendered manuscript pages."""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 20)

for language in ("en", "zh"):
    render_dir = ROOT / f"qa/render_{language}"
    paths = sorted(render_dir.glob("page-*.png"), key=lambda p: int(p.stem.split("-")[-1]))
    output_dir = ROOT / f"qa/contact_{language}"
    output_dir.mkdir(exist_ok=True)
    for start in range(0, len(paths), 2):
        pair = paths[start:start + 2]
        images = [Image.open(path).convert("RGB") for path in pair]
        width = max(im.width for im in images)
        height = max(im.height for im in images)
        canvas = Image.new("RGB", (2 * width + 36, height + 54), "#e4e8ec")
        draw = ImageDraw.Draw(canvas)
        for offset, (path, im) in enumerate(zip(pair, images)):
            x = 12 + offset * (width + 12)
            canvas.paste(im, (x, 42))
            page = int(path.stem.split("-")[-1])
            draw.text((x + 8, 9), f"{language.upper()} | page {page}", fill="#203040", font=font)
        canvas.save(output_dir / f"pages-{start + 1:02d}-{min(start + 2, len(paths)):02d}.png")
    print(f"{language}: {len(paths)} pages -> {len(list(output_dir.glob('*.png')))} contact sheets")
