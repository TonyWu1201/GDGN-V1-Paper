"""Deterministically reanalyse archived GDGN B4-era text/JSON/CSV records.

No checkpoints are loaded; no model inference or training is performed. Saved
attention--IG correlations are imported, not recomputed: the archive preserves
only attention top-20 names rather than complete attention vectors.

Run from any working directory with the project's uv-managed Python, or:
uv run --no-project --python <bundled-Python-path> python paper_v1/scripts/reanalyse_legacy.py
Requires numpy and reportlab; neither SciPy nor PyTorch is needed.
"""

from __future__ import annotations

import csv
import hashlib
import itertools
import json
import math
import platform
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import reportlab
from reportlab.lib.colors import Color, HexColor
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "paper_v1"
RESULTS = OUT / "results"
FIGURES = OUT / "figures"
PROVENANCE = OUT / "provenance"
SOURCES: set[Path] = set()
PRODUCTS: set[Path] = set()

MODELS = [
    ("A0", "data/model/gdgn"),
    ("A1", "data/model/ablation/01_main"),
    ("A4", "data/model/ablation/04_no_pretrain"),
    ("B1", "data/model/arch/B1_bypass_residual"),
    ("B3", "data/model/arch/B3_bypass_cat"),
    ("B4", "data/model/arch/B4_dual_encoder"),
    ("Flatten", "data/model/baseline"),
    ("CDR adapter", "data/model/cdr_baseline"),
]


def read_text(relative: str) -> str:
    path = ROOT / relative
    SOURCES.add(path)
    raw = path.read_bytes()
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        # Legacy split_stats.txt was saved with the Windows Chinese locale.
        return raw.decode("gb18030")


def read_json(relative: str):
    return json.loads(read_text(relative))


def read_csv(relative: str) -> list[dict]:
    return list(csv.DictReader(read_text(relative).splitlines()))


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    PRODUCTS.add(path)


def write_csv(name: str, rows: list[dict]) -> None:
    path = RESULTS / name
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    PRODUCTS.add(path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for part in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(part)
    return digest.hexdigest()


def analyse_performance() -> list[dict]:
    rows = []
    for label, directory in MODELS:
        report = read_text(f"{directory}/final_eval_report.txt")
        config = read_json(f"{directory}/trained_config.json")
        # The first split block has all six metric columns; the subsequent
        # no-DTI subset uses fewer columns and is parsed separately below.
        match = re.search(r"^test\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+(\d+)\s*$", report, re.M)
        if not match:
            raise ValueError(f"Missing full test metric row: {directory}")
        pcc, spr, rmse, mae, mse = map(float, match.groups()[:5])
        n = int(match.group(6))
        subset = re.search(r"^test\s+([\d.]+)\s+([\d.]+)\s+(\d+)\s+(\d+)\s*$", report, re.M)
        epoch = re.search(r"^best epoch:\s*(\d+)", report, re.M)
        rows.append({
            "model": label, "test_pcc": pcc, "test_spearman": spr,
            "test_rmse": rmse, "test_mae": mae, "test_mse": mse, "test_n": n,
            "seed": config.get("seed"), "best_epoch": int(epoch.group(1)) if epoch else None,
            "pretrained": bool(config.get("pretrain_ckpt")),
            "main_drug_embedding": config.get("use_main_drug_emb"),
            "encoder_lr": config.get("lr_encoder"), "batch_size": config.get("batch_size"),
            "dual_cell": config.get("dual_cell", False),
            "bypass_mode": config.get("cell_bypass_mode", "none"),
            "flagged_seven_test_pcc": float(subset.group(1)) if subset else None,
            "flagged_seven_test_rmse": float(subset.group(2)) if subset else None,
            "flagged_seven_test_n": int(subset.group(3)) if subset else None,
            "report": f"{directory}/final_eval_report.txt",
            "configuration": f"{directory}/trained_config.json",
        })
    assert len({row["test_n"] for row in rows}) == 1
    write_csv("model_performance.csv", rows)
    return rows


def analyse_graphs() -> tuple[list[dict], dict]:
    rows, duplicates = [], {}
    for model in ("a4", "b4"):
        source = f"data/model/interpretability/graph_ablation_{model}/graph_ablation_report.json"
        records = read_json(source)
        reference = next(row for row in records if row["mode"] == "original")
        originals = [r for r in records if r["mode"] == "original"]
        duplicates[model.upper()] = {
            "original_rows": len(originals),
            "maximum_original_pcc_discrepancy": max(abs(r["pcc"] - reference["pcc"]) for r in originals),
            "maximum_original_rmse_discrepancy": max(abs(r["rmse"] - reference["rmse"]) for r in originals),
        }
        seen = set()
        for record in records:
            if record["mode"] in seen:
                continue
            seen.add(record["mode"])
            rows.append({
                "model": model.upper(), "mode": record["mode"],
                "pcc": record["pcc"], "delta_pcc": record["pcc"] - reference["pcc"],
                "rmse": record["rmse"], "delta_rmse": record["rmse"] - reference["rmse"],
                "spearman": record["spearman"], "n": record["n"],
                "description": record["desc"], "source": source,
            })
    write_csv("graph_perturbation.csv", rows)
    return rows, duplicates


def jaccard(a: set[str], b: set[str]) -> float:
    return len(a & b) / len(a | b)


def analyse_cases(genes: list[str], targets: dict[int, set[str]], metadata: dict[str, dict], cells: dict[int, str]):
    source = "data/model/interpretability/gdgn_b4/cases.json"
    cases = read_json(source)
    universe = set(genes)
    rows = []
    for position, case in enumerate(cases, start=1):
        if len(case["ig_per_gene"]) != len(genes):
            raise ValueError("Saved attribution dimension does not match current core gene order")
        # Compare names to saved IG ranking as a mapping consistency check.
        # Numpy is used for sorting only: the historical IG values are preserved.
        order = np.argsort(-np.asarray(case["ig_per_gene"]), kind="stable")[:20]
        reconstructed_ig = [genes[int(i)] for i in order]
        saved_ig = case["dti_validation"]["top_genes"]
        if reconstructed_ig != saved_ig:
            raise ValueError(f"Gene-order/ranking mismatch: {case['case']}")
        cid = case["cid"]
        candidate = targets.get(cid, set())
        measurable = candidate & universe
        ig_hits = sorted(measurable & set(saved_ig))
        attn_hits = sorted(measurable & set(case["attn_top"]))
        n = len(measurable)
        # P(X >= 1) for a uniform top-20 without replacement. It is a
        # per-case null reference, not a multi-case significance test.
        probability = 1.0 - math.prod((len(genes) - n - i) / (len(genes) - i) for i in range(20)) if n else None
        rows.append({
            "case_number": position, "case": case["case"], "drug_idx": case["drug_idx"],
            "cid": cid, "drug_name": metadata[str(cid)]["GDSC_DRUG_NAME"],
            "cell_idx": case["cell_idx"], "cell_line": cells[case["cell_idx"]],
            "phenotype": case["cell_type"], "saved_attention_ig_spearman": case["attn_ig_spearman"],
            "archived_target_count": case["dti_validation"]["n_targets_known"],
            "csv_target_count": len(candidate), "core_measurable_target_count": n,
            "ig_top20_hits": len(ig_hits) if n else None,
            "attention_top20_hits": len(attn_hits) if n else None,
            "random_expected_hits": 20 * n / len(genes) if n else None,
            "random_probability_at_least_one_hit": probability,
            "measurable_targets": ";".join(sorted(measurable)),
            "ig_top20": ";".join(saved_ig), "attention_top20": ";".join(case["attn_top"]),
            "attention_top5": ";".join(case["attn_top"][:5]),
        })
    write_csv("attention_cases.csv", rows)
    pair_rows = []
    matrices = {name: np.eye(len(cases)) for name in ("attention", "ig")}
    for i, j in itertools.combinations(range(len(cases)), 2):
        a1, a2 = set(cases[i]["attn_top"]), set(cases[j]["attn_top"])
        g1, g2 = set(cases[i]["dti_validation"]["top_genes"]), set(cases[j]["dti_validation"]["top_genes"])
        av, gv = jaccard(a1, a2), jaccard(g1, g2)
        matrices["attention"][i, j] = matrices["attention"][j, i] = av
        matrices["ig"][i, j] = matrices["ig"][j, i] = gv
        pair_rows.append({
            "case_i": i + 1, "case_j": j + 1,
            "same_drug": cases[i]["drug_idx"] == cases[j]["drug_idx"],
            "same_cell": cases[i]["cell_idx"] == cases[j]["cell_idx"],
            "attention_top20_jaccard": av, "attention_top20_intersection": len(a1 & a2),
            "ig_top20_jaccard": gv, "ig_top20_intersection": len(g1 & g2),
        })
    write_csv("top20_pairwise_overlap.csv", pair_rows)
    for name, matrix in matrices.items():
        write_csv(f"{name}_top20_jaccard_matrix.csv", [dict(case_number=i + 1, **{f"case_{j+1}": float(matrix[i, j]) for j in range(len(cases))}) for i in range(len(cases))])
    signature_counts = Counter(tuple(c["attn_top"][:5]) for c in cases)
    signatures = [{"count": count, "genes": list(signature)} for signature, count in signature_counts.most_common()]
    rho = np.asarray([row["saved_attention_ig_spearman"] for row in rows])
    correlations_by_drug = [float(np.mean([r["saved_attention_ig_spearman"] for r in rows if r["drug_idx"] == idx])) for idx in sorted({r["drug_idx"] for r in rows})]
    summary = {
        "n_cases": len(rows), "n_drugs": len({r["drug_idx"] for r in rows}),
        "n_core_genes": len(genes), "rho_source": "stored scalar; complete attention vectors unavailable",
        "rho_mean": float(rho.mean()), "rho_median": float(np.median(rho)),
        "rho_min": float(rho.min()), "rho_max": float(rho.max()),
        "rho_drug_mean_values": correlations_by_drug,
        "n_target_evaluable_cases": sum(r["core_measurable_target_count"] > 0 for r in rows),
        "n_target_unavailable_cases": sum(r["core_measurable_target_count"] == 0 for r in rows),
        "n_target_evaluable_drugs": len({r["drug_idx"] for r in rows if r["core_measurable_target_count"]}),
        "ig_hit_cases": sum(bool(r["ig_top20_hits"]) for r in rows),
        "attention_hit_cases": sum(bool(r["attention_top20_hits"]) for r in rows),
        "random_expected_total_hits_evaluable_cases": sum(r["random_expected_hits"] or 0 for r in rows),
        "ig_gene_order_check": "all ten reconstructed top-20 rankings exactly match archived names",
        "attention_top5_signatures": signatures,
        "n_distinct_attention_top20_sets": len({tuple(sorted(c["attn_top"])) for c in cases}),
        "n_pairwise_comparisons_descriptive": len(pair_rows),
    }
    for metric in ("attention", "ig"):
        for group_name, selected in (("all", pair_rows), ("within_drug", [p for p in pair_rows if p["same_drug"]]), ("between_drug", [p for p in pair_rows if not p["same_drug"]])):
            values = [p[f"{metric}_top20_jaccard"] for p in selected]
            summary[f"{metric}_top20_jaccard_{group_name}"] = {
                "n_pairs": len(values), "mean": float(np.mean(values)),
                "minimum": min(values), "maximum": max(values),
            }
    return rows, summary, matrices


def analyse_coverage(genes: list[str], targets: dict[int, set[str]], metadata: dict[str, dict]):
    mapping = {int(cid): int(idx) for cid, idx in read_json("data/processed/drug_cid_to_idx.json").items()}
    flagged = read_json("data/model/gdgn/no_dti_drug_idx.json")
    universe = set(genes)
    rows = []
    for cid, idx in sorted(mapping.items(), key=lambda pair: pair[1]):
        raw = targets.get(cid, set())
        core = raw & universe
        if idx not in flagged and core:
            continue
        entry = metadata[str(cid)]
        rows.append({
            "drug_idx": idx, "cid": cid, "drug_name": entry["GDSC_DRUG_NAME"],
            "archived_seven_flag": idx in flagged, "csv_target_count": len(raw),
            "core_target_count": len(core), "excluded_target_names": ";".join(sorted(raw - universe)),
            "archived_putative_target": entry["PUTATIVE_TARGET"],
            "archived_pathway": entry["PATHWAY_NAME"],
        })
    write_csv("dti_coverage_flags.csv", rows)
    raw_zero = sorted(idx for cid, idx in mapping.items() if not targets.get(cid))
    core_zero = sorted(idx for cid, idx in mapping.items() if not (targets.get(cid, set()) & universe))
    assert raw_zero == sorted(flagged)
    return {
        "project_drug_count": len(mapping), "core_gene_count": len(genes),
        "archived_flag_count": len(flagged), "archived_flag_indices": flagged,
        "csv_project_zero_target_indices": raw_zero,
        "csv_core_zero_target_indices": core_zero, "csv_core_zero_target_count": len(core_zero),
        "additional_core_zero_indices": sorted(set(core_zero) - set(flagged)),
        "csv_unique_project_core_drug_gene_pairs": sum(len(targets.get(cid, set()) & universe) for cid in mapping),
        "csv_cids_outside_project": sorted(set(targets) - set(mapping)),
        "scope": "coverage reconstructed from current filtered CSV, CID map, and core gene order; graph tensors not loaded",
    }


# ReportLab is a plotting backend here: axes and marks remain vector objects.
INK = HexColor("#172B3A")
GRAY = HexColor("#597180")
GRID = HexColor("#DCE4E8")
TEAL = HexColor("#167C80")
ORANGE = HexColor("#C77B31")
BLUE = HexColor("#356CA3")
# Figures are embedded at approximately 466 pt in the manuscript. At their
# 760--790 pt native width, this gives 7+ pt ticks and 10+ pt panel headings.
FIGURE_FONT_SCALE = 1.5


def label(c, x, y, text, size=9, color=INK, align="left", bold=False):
    c.setFillColor(color)
    c.setFont("Helvetica-Bold" if bold else "Helvetica", size * FIGURE_FONT_SCALE)
    {"left": c.drawString, "right": c.drawRightString, "center": c.drawCentredString}[align](x, y, str(text))


def start_figure(name, title, width=760, height=360):
    path = FIGURES / name
    c = canvas.Canvas(str(path), pagesize=(width, height), invariant=1, pageCompression=1)
    c.setTitle(title)
    c.setAuthor("GDGN B4 archived-record reanalysis")
    c.setSubject("Deterministic summary of saved records; no new training or inference")
    c.setLineWidth(0.6)
    return c, path


def finish_figure(c, path):
    c.showPage()
    c.save()
    PRODUCTS.add(path)


def axis_x(c, x, y, width, lo, hi, ticks, top_y, number=".2f"):
    scale = lambda value: x + width * (value - lo) / (hi - lo)
    for tick in ticks:
        tx = scale(tick)
        c.setStrokeColor(GRID)
        c.line(tx, y, tx, top_y)
        label(c, tx, y - 15, format(tick, number), 8, GRAY, "center")
    c.setStrokeColor(INK)
    c.line(x, y, x + width, y)
    return scale


def performance_figure(rows):
    c, path = start_figure("fig_performance.pdf", "Archived random-pair test performance")
    label(c, 24, 336, "A  Random-pair test PCC", 12, bold=True)
    label(c, 395, 336, "B  Random-pair test RMSE", 12, bold=True)
    xp = axis_x(c, 105, 66, 225, .89, .95, [.89, .90, .91, .92, .93, .94, .95], 309)
    xr = axis_x(c, 480, 66, 225, .95, 1.30, [.95, 1.00, 1.10, 1.20, 1.30], 309)
    for i, row in enumerate(rows):
        y = 295 - i * 29
        color = ORANGE if row["model"] == "B4" else TEAL if row["model"] == "Flatten" else BLUE
        label(c, 96, y - 3, row["model"], 9, align="right")
        label(c, 470, y - 3, row["model"], 9, align="right")
        c.setFillColor(color)
        c.rect(xp(.89), y - 6, xp(row["test_pcc"]) - xp(.89), 12, fill=1, stroke=0)
        c.circle(xr(row["test_rmse"]), y, 4.0, fill=1, stroke=0)
        label(c, xp(row["test_pcc"]) + 5, y - 3, f"{row['test_pcc']:.4f}", 8)
        label(c, xr(row["test_rmse"]) + 7, y - 3, f"{row['test_rmse']:.4f}", 8)
    label(c, 218, 32, "Pearson correlation (PCC)", 10, align="center")
    label(c, 593, 32, "RMSE (LN_IC50 scale)", 10, align="center")
    label(c, 24, 12, "Archived runs: seed 42; 6,655 test pairs. PCC axis starts at 0.89.", 8, GRAY)
    finish_figure(c, path)


def attention_figure(rows, summary, matrices):
    c, path = start_figure("fig_attention.pdf", "Attention and attribution diagnostics", 790, 390)
    label(c, 22, 365, "A  Saved attention-IG correlation", 12, bold=True)
    label(c, 425, 365, "B  Top-20 Jaccard overlap", 12, bold=True)
    xs = axis_x(c, 150, 76, 210, -.010, .015, [-.01, -.005, 0, .005, .01, .015], 335, ".3f")
    c.setStrokeColor(GRAY)
    c.setDash(2, 2)
    c.line(xs(0), 76, xs(0), 335)
    c.setDash()
    for i, row in enumerate(rows):
        y = 321 - i * 24
        short = "S" if row["phenotype"] == "sensitive" else "R"
        label(c, 140, y - 3, f"{i+1}. {row['drug_name']} {short}", 8.2, align="right")
        c.setFillColor(TEAL if row["core_measurable_target_count"] else ORANGE)
        c.circle(xs(row["saved_attention_ig_spearman"]), y, 3.8, stroke=0, fill=1)
    label(c, 255, 47, "Spearman correlation (stored)", 9, align="center")
    label(c, 22, 25, f"Mean = {summary['rho_mean']:.6f}; 5 drugs, 10 cases.", 8.2, GRAY)
    label(c, 22, 12, "Teal: retained annotation; orange: recovery N/A.", 8.2, GRAY)
    grid_x, grid_top, size = 470, 335, 23
    for i in range(len(rows)):
        label(c, grid_x - 9, grid_top - (i + .5) * size - 3, i + 1, 8, align="right")
        label(c, grid_x + (i + .5) * size, grid_top + 6, i + 1, 8, align="center")
        for j in range(len(rows)):
            if i == j:
                fill = HexColor("#F3F5F6")
            else:
                value = matrices["attention" if i < j else "ig"][i, j]
                fill = Color(.95 - .80 * value, .97 - .51 * value, .99 - .31 * value)
            c.setFillColor(fill)
            c.setStrokeColor(Color(1, 1, 1))
            c.rect(grid_x + j * size, grid_top - (i + 1) * size, size, size, stroke=1, fill=1)
    label(c, grid_x + 115, 85, "Upper: attention; lower: IG", 8.5, align="center")
    legend_y = 62
    for j in range(100):
        v = j / 99
        c.setFillColor(Color(.95 - .80 * v, .97 - .51 * v, .99 - .31 * v))
        c.rect(grid_x + j * 2.3, legend_y, 2.4, 9, fill=1, stroke=0)
    label(c, grid_x, 48, "0", 8, GRAY)
    label(c, grid_x + 230, 48, "1", 8, GRAY, "right")
    label(c, grid_x + 115, 48, "Jaccard similarity", 8, GRAY, "center")
    label(c, 425, 25, f"Mean Jaccard: attention {summary['attention_top20_jaccard_all']['mean']:.3f}; IG {summary['ig_top20_jaccard_all']['mean']:.3f}.", 8.2, GRAY)
    label(c, 425, 12, "Numbers match panel A; case pairs are descriptive.", 8.2, GRAY)
    finish_figure(c, path)


def graph_figure(rows):
    c, path = start_figure("fig_graph.pdf", "Fixed-checkpoint biological-graph sensitivity", 790, 360)
    label(c, 22, 336, "A  Random-pair test PCC change", 12, bold=True)
    label(c, 415, 336, "B  Random-pair test RMSE", 12, bold=True)
    xp = axis_x(c, 115, 67, 235, -.16, .01, [-.15, -.10, -.05, 0], 306)
    xr = axis_x(c, 500, 67, 235, 1.0, 2.6, [1.0, 1.4, 1.8, 2.2, 2.6], 306, ".1f")
    by_key = {(r["model"], r["mode"]): r for r in rows}
    modes = [("original", "Original"), ("permute_ppi", "Rewire PPI"), ("permute_dti", "Rewire DTI"), ("permute_both", "Rewire both"), ("remove_ppi", "PPI -> self-loops"), ("remove_dti", "DTI -> dummy"), ("remove_both", "Both replacements")]
    c.setStrokeColor(GRAY)
    c.line(xp(0), 67, xp(0), 306)
    for i, (mode, text) in enumerate(modes):
        y = 293 - i * 31
        label(c, 107, y - 3, text, 8, align="right")
        label(c, 492, y - 3, text, 8, align="right")
        for model, offset, color in (("A4", 4.6, TEAL), ("B4", -4.6, ORANGE)):
            row = by_key[model, mode]
            c.setFillColor(color)
            end = xp(row["delta_pcc"])
            if mode == "original":
                c.circle(xp(0), y + offset, 2.6, fill=1, stroke=0)
            else:
                c.rect(min(end, xp(0)), y + offset - 3.8, abs(end - xp(0)), 7.6, fill=1, stroke=0)
            c.circle(xr(row["rmse"]), y + offset, 3.3, fill=1, stroke=0)
    label(c, 235, 35, "PCC: perturbed - original", 9.5, align="center")
    label(c, 615, 35, "RMSE (LN_IC50 scale)", 9.5, align="center")
    for xx, name, color in ((310, "A4", TEAL), (373, "B4", ORANGE)):
        c.setFillColor(color)
        c.rect(xx, 11, 10, 8, fill=1, stroke=0)
        label(c, xx + 15, 11, name, 8.5)
    label(c, 22, 11, "Fixed checkpoints; N = 6,655.", 8, GRAY)
    label(c, 450, 11, "Destinations redrawn independently.", 8, GRAY)
    finish_figure(c, path)


def main():
    for directory in (RESULTS, FIGURES, PROVENANCE):
        directory.mkdir(parents=True, exist_ok=True)
    genes = read_text("data/model/hetero_graph/core_gene_order.txt").splitlines()
    if len(genes) != len(set(genes)):
        raise ValueError("Duplicate core gene names")
    interactions = read_csv("data/processed/drug_gene_interaction/interactions_filtered.csv")
    targets = defaultdict(set)
    for row in interactions:
        targets[int(row["cid"])].add(row["gene_name"])
    metadata = {row["CID"]: row for row in read_csv("data/common_drugs_pubchem.csv")}
    cells = {int(idx): name for name, idx in read_json("data/processed/cell_line_to_idx.json").items()}
    performance = analyse_performance()
    graph_rows, duplicates = analyse_graphs()
    case_rows, case_summary, matrices = analyse_cases(genes, targets, metadata, cells)
    coverage = analyse_coverage(genes, targets, metadata)
    coverage["csv_total_records"] = len(interactions)
    coverage["csv_unique_cids"] = len(targets)
    stats = read_text("data/processed/split_stats.txt")
    split_counts = {}
    for key, pattern in (("total", r"Total pairs:\s*(\d+)"), ("train", r"Train:\s*(\d+)"), ("validation", r"Val:\s*(\d+)"), ("test", r"Test:\s*(\d+)")):
        split_counts[key] = int(re.search(pattern, stats).group(1))
    summary = {
        "analysis_date": "2026-10-12", "analysis_type": "deterministic archived-record reanalysis",
        "new_training_runs": 0, "new_inference_runs": 0,
        "split_counts_from_archived_text": split_counts,
        "performance": performance, "graph_perturbation": graph_rows,
        "duplicate_original_rows": duplicates, "attention": case_summary,
        "dti_coverage": coverage,
        "scope_notes": [
            "All performance and perturbation predictions are archived observations, not newly generated predictions.",
            "One saved seed is available per model; no significance tests or confidence intervals across training seeds are inferred.",
            "Attention-IG rho values are imported from saved case records; full attention vectors are unavailable.",
            "Ten selected cases represent five drugs and are not treated as independent drug replicates.",
            "Target recovery uses the intersection of filtered CSV targets with the current 8,412-gene core universe; absent targets are N/A.",
            "The model graph edge tensors and historical checkpoint/input correspondence are not verified by this text/JSON/CSV reanalysis.",
            "Archived generalization reports are excluded because they reuse trained-on observations and are not cold-start evaluations.",
            "Only B4 and earlier model records are used; defense-stage materials are excluded.",
        ],
    }
    write_json(RESULTS / "summary.json", summary)
    # Save the numerical summary before drawing so manuscript authors can read
    # it while layout verification proceeds independently.
    performance_figure(performance)
    attention_figure(case_rows, case_summary, matrices)
    graph_figure(graph_rows)
    common = {(row["model"], row["mode"]): row for row in graph_rows}
    report = [
        "# Archived GDGN B4-era evidence reanalysis", "",
        "Date: 2026-10-12. This script reads archived reports and explanatory records. It performs no training, inference, or new IG computation.", "",
        "## Random-pair test performance", "",
        "Eight archived seed-42 configurations each report 6,655 test pairs. The report precision is four decimals; split tensor membership was not rechecked.", "",
        "| Model | PCC | RMSE | MAE | Pretraining | Main drug embedding |",
        "|---|---:|---:|---:|---|---|",
    ]
    for row in performance:
        report.append(f"| {row['model']} | {row['test_pcc']:.4f} | {row['test_rmse']:.4f} | {row['test_mae']:.4f} | {row['pretrained']} | {row['main_drug_embedding']} |")
    report += ["", "A1 and A4 change both pretraining and the main drug embedding. Their observed difference is a comparison of configurations, not an isolated pretraining effect.", "", "## Attention, IG, and target coverage", "",
        f"The ten selected cases cover five drugs. Imported rank correlations average {case_summary['rho_mean']:.12f}, with range [{case_summary['rho_min']:.12f}, {case_summary['rho_max']:.12f}]. Full attention vectors are absent, so these rho values cannot be independently recalculated here.", "",
        f"The mean top-20 Jaccard is {case_summary['attention_top20_jaccard_all']['mean']:.9f} for attention and {case_summary['ig_top20_jaccard_all']['mean']:.9f} for saved IG. These are 45 overlapping case pairs, reported descriptively rather than as independent statistical observations.", "",
        f"The most common ordered attention top-5 signature occurs in {case_summary['attention_top5_signatures'][0]['count']}/10 cases: " + ", ".join(case_summary['attention_top5_signatures'][0]['genes']) + ".", "",
        "All ten reconstructed IG top-20 names exactly match the saved top-20 names under the current core gene order. This checks the selected gene mapping, not the full historical input/checkpoint correspondence.", "",
        f"Six cases (three drugs) have measurable filtered-CSV targets; four cases are N/A. IG top-20 and attention top-20 each have zero hits in the six eligible cases. The uniform top-20 random expected total is {case_summary['random_expected_total_hits_evaluable_cases']:.12f}; a zero-hit outcome therefore has little discriminatory power in this small target set.", "",
        "## Fixed-checkpoint graph perturbations", "",
        "The first A4 original record is the reference; its duplicate differs only at numerical precision and is not a replicate. Delta means perturbed minus original.", "",
        "| Mode | A4 delta PCC | B4 delta PCC | A4 RMSE | B4 RMSE |",
        "|---|---:|---:|---:|---:|",
    ]
    for mode in ["original", "permute_ppi", "permute_dti", "permute_both", "remove_ppi", "remove_dti", "remove_both"]:
        a, b = common["A4", mode], common["B4", mode]
        report.append(f"| {mode} | {a['delta_pcc']:.9f} | {b['delta_pcc']:.9f} | {a['rmse']:.6f} | {b['rmse']:.6f} |")
    report += ["", "PPI removal replaces PPI with self-loops; DTI removal keeps a dummy edge. Historical random rewiring preserves source lists and edge counts but not target degrees, and opposite relations are generated separately. These values measure fixed-checkpoint sensitivity under that implementation.", "",
        "## Reconstructed DTI coverage", "",
        f"The archived seven-drug list exactly matches zero filtered-CSV targets among 184 mapped drugs: {coverage['archived_flag_indices']}. Intersecting targets with the core gene universe yields {coverage['csv_core_zero_target_count']} zero-coverage drugs: {coverage['csv_core_zero_target_indices']}.", "",
        "The four additional drug indices [121, 158, 168, 172] have only out-of-core target symbols (F7R; FRA9D; GLC# and GLC1B; GLC3B). The reconstructed core universe contains 1,124 unique mapped drug-gene pairs, matching the edge count stated in the perturbation logs. Graph tensors were not loaded, so the wording remains reconstructed coverage.", "",
        "No DTI means absent from this mapping and filtering procedure; the manuscript does not equate it with absence of pharmacological targets.", "",
        "## Split-count provenance", "",
        f"Archived split_stats.txt records {split_counts['total']:,} observed pairs: {split_counts['train']:,} train, {split_counts['validation']:,} validation, {split_counts['test']:,} test. Training evaluation rows may use fewer pairs due to batching/drop_last. These counts are transcribed from text; split tensor membership was not verified in this run.", "",
        "## Outputs and reproducibility", "",
        "The executable script, source hashes, machine-readable summaries, CSV tables, and three vector-PDF figures are included. PDF generation uses ReportLab invariant mode. No current defense presentation, defense-stage case study, later model, or archived cold-start label is used.", "",
    ]
    report_path = RESULTS / "reanalysis_report.md"
    report_path.write_text("\n".join(report), encoding="utf-8")
    PRODUCTS.add(report_path)
    manifest = {
        "analysis_date": "2026-10-12", "script": str(Path(__file__).relative_to(ROOT)).replace("\\", "/"),
        "script_sha256": sha256(Path(__file__)), "python": platform.python_version(),
        "numpy": np.__version__, "reportlab": reportlab.Version,
        "command": "uv run --no-project --python <bundled-Python-path> python paper_v1/scripts/reanalyse_legacy.py",
        "new_training_runs": 0, "new_inference_runs": 0,
        "input_files": [{"path": p.relative_to(ROOT).as_posix(), "sha256": sha256(p), "size_bytes": p.stat().st_size} for p in sorted(SOURCES)],
        "output_files": [{"path": p.relative_to(ROOT).as_posix(), "sha256": sha256(p), "size_bytes": p.stat().st_size} for p in sorted(PRODUCTS)],
    }
    write_json(PROVENANCE / "reanalysis_manifest.json", manifest)
    print(json.dumps({"output": str(RESULTS / 'summary.json'), "models": len(performance), "cases": case_summary['n_cases'], "attention_jaccard": case_summary['attention_top20_jaccard_all'], "ig_jaccard": case_summary['ig_top20_jaccard_all'], "core_zero_drugs": coverage['csv_core_zero_target_count'], "figures": 3}, indent=2))


if __name__ == "__main__":
    main()
