"""Package checked v2 sources after final visual review; preserve v1 unchanged."""

from __future__ import annotations

import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from check_manuscripts import (
    BASELINE_PATH, PDF_NAMES, ROOT, read_json, require, sha256,
    verify_provenance, verify_source_hashes,
)

RELEASE = ROOT / "release"
ARCHIVE_NAME = "GDGN_review_v2_sources.zip"


def main() -> None:
    provenance = verify_provenance()
    baseline = read_json(BASELINE_PATH)
    checks_path = ROOT / "qa/manuscript_checks.json"
    visual_path = ROOT / "qa/visual_review.md"
    checks = read_json(checks_path)
    require(checks.get("revision") == "paper_v2", "Run the v2 manuscript checks first")
    require(checks["source_math_and_reference_equivalence"], "Resolve bilingual source differences first")
    require(checks["provenance"]["revision_baseline_sha256"] == sha256(BASELINE_PATH), "Revision baseline changed after QA")
    verify_source_hashes(checks["source_files"], from_project=False)
    require(visual_path.is_file(), "Record final visual inspection in paper_v2/qa/visual_review.md")
    visual = visual_path.read_text(encoding="utf-8").lower()
    for language in ("en", "zh"):
        pdf = RELEASE / PDF_NAMES[language]
        require(sha256(pdf) == checks["pdfs"][language]["sha256"], f"PDF changed after QA: {language}")
        require(not checks["compilation"][language]["errors"], f"Resolve compilation errors: {language}")
        require(sha256(pdf) in visual, f"Bind visual review to final PDF SHA256: {language}")

    extensions = {".tex", ".bbl", ".bib", ".pdf", ".py", ".ps1", ".json", ".csv", ".md"}
    files = []
    for directory in ("manuscript_en", "manuscript_zh", "shared", "tables", "figures",
                      "scripts", "results", "references", "provenance", "qa"):
        folder = ROOT / directory
        require(folder.is_dir(), f"Missing source directory: {folder}")
        for path in folder.rglob("*"):
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            if directory.startswith("manuscript_") and path.suffix not in (".tex", ".bbl"):
                continue
            if directory == "figures" and path.suffix != ".pdf":
                continue
            if path.suffix in extensions:
                files.append(path)
    for name in ("README.md", "revision_notes.md"):
        path = ROOT / name
        require(path.is_file(), f"Missing release documentation: {name}")
        files.append(path)
    for name in ("plan.md", "todo.md", "evidence_audit.md"):
        path = ROOT / name
        if path.is_file():
            files.append(path)
    files = sorted(set(files))
    RELEASE.mkdir(exist_ok=True)
    archive_path = RELEASE / ARCHIVE_NAME
    timestamp = tuple(map(int, baseline["date"].split("-"))) + (0, 0, 0)
    with ZipFile(archive_path, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            info = ZipInfo("paper_v2/" + path.relative_to(ROOT).as_posix(), timestamp)
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    with ZipFile(archive_path) as archive:
        require(archive.testzip() is None, "Source ZIP failed its CRC check")
        require(len(archive.namelist()) == len(files), "ZIP member-count mismatch")
        for path in files:
            require(archive.read("paper_v2/" + path.relative_to(ROOT).as_posix()) == path.read_bytes(),
                    f"ZIP file-content mismatch: {path}")
    verify_provenance()
    artifacts = [RELEASE / PDF_NAMES[lang] for lang in ("en", "zh")] + [archive_path]
    manifest = {
        "date": baseline["date"], "revision": "paper_v2",
        "kind": "revised narrative review and retrospective case study",
        "new_training_runs": 0, "new_inference_runs": 0,
        "source_archive_file_count": len(files), "archive_root": "paper_v2/",
        "v1_files_preserved": provenance["v1_files_preserved"],
        "revision_baseline_sha256": sha256(BASELINE_PATH),
        "manuscript_checks_sha256": sha256(checks_path), "visual_review_sha256": sha256(visual_path),
        "artifacts": [{"path": p.relative_to(ROOT).as_posix(), "size_bytes": p.stat().st_size,
                       "sha256": sha256(p)} for p in artifacts],
        "source_files": [{"path": p.relative_to(ROOT).as_posix(), "sha256": sha256(p)} for p in files],
    }
    (RELEASE / "release_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"source_archive_files": len(files), "artifacts": manifest["artifacts"]},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
