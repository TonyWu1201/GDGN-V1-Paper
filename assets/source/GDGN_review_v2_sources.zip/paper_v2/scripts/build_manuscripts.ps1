param(
    [ValidateSet('en', 'zh', 'all')]
    [string]$Language = 'all'
)

$ErrorActionPreference = 'Stop'
$paperRoot = Split-Path -Parent $PSScriptRoot
$releaseDir = Join-Path $paperRoot 'release'
$logRoot = Join-Path $paperRoot 'qa/compile'
New-Item -ItemType Directory -Force -Path $releaseDir, $logRoot | Out-Null
$languages = if ($Language -eq 'all') { @('en', 'zh') } else { @($Language) }

foreach ($lang in $languages) {
    $sourceDir = Join-Path $paperRoot "manuscript_$lang"
    $logDir = Join-Path $logRoot $lang
    New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    Push-Location -LiteralPath $sourceDir
    try {
        & xelatex -interaction=nonstopmode -halt-on-error -file-line-error main.tex *> (Join-Path $logDir 'xelatex-1.txt')
        if ($LASTEXITCODE -ne 0) { throw "XeLaTeX first pass failed: $lang; see $logDir" }
        & bibtex main *> (Join-Path $logDir 'bibtex.txt')
        if ($LASTEXITCODE -ne 0) { throw "BibTeX failed: $lang; see $logDir" }
        foreach ($pass in 2..3) {
            & xelatex -interaction=nonstopmode -halt-on-error -file-line-error main.tex *> (Join-Path $logDir "xelatex-$pass.txt")
            if ($LASTEXITCODE -ne 0) { throw "XeLaTeX pass $pass failed: $lang; see $logDir" }
        }
        Copy-Item -LiteralPath (Join-Path $sourceDir 'main.log') -Destination (Join-Path $logDir 'main.log') -Force
        Copy-Item -LiteralPath (Join-Path $sourceDir 'main.blg') -Destination (Join-Path $logDir 'main.blg') -Force
        $pdfPath = Join-Path $releaseDir "GDGN_review_v2_$lang.pdf"
        Copy-Item -LiteralPath (Join-Path $sourceDir 'main.pdf') -Destination $pdfPath -Force
        Write-Output "Built $pdfPath"
    }
    finally {
        Pop-Location
    }
}
