"""Check v2 bilingual sources, compiled PDFs and the preserved v1 evidence chain.

Use --provenance-only before writing/building, --sources-only before compilation,
or no option after build_manuscripts.ps1. This script never reruns analysis.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
QA = ROOT / "qa"
BASELINE_PATH = ROOT / "provenance/revision_baseline.json"
PDF_NAMES = {lang: f"GDGN_review_v2_{lang}.pdf" for lang in ("en", "zh")}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def project_path(relative: str) -> Path:
    path = (PROJECT / relative).resolve()
    require(path.is_relative_to(PROJECT.resolve()), f"Path outside project: {relative}")
    return path


def verify_source_hashes(items: list[dict], *, from_project: bool = True) -> None:
    for item in items:
        path = project_path(item["path"]) if from_project else ROOT / item["path"]
        require(path.is_file(), f"Missing recorded file: {path}")
        require(sha256(path) == item["sha256"], f"Recorded file changed: {path}")


def verify_provenance() -> dict:
    baseline = read_json(BASELINE_PATH)
    old_root = project_path(baseline["v1_directory"])
    current = sorted(p.relative_to(PROJECT).as_posix() for p in old_root.rglob("*") if p.is_file())
    expected = sorted(item["path"] for item in baseline["v1_files"])
    require(current == expected, "The preserved v1 file inventory changed")
    verify_source_hashes(baseline["v1_files"])
    for item in baseline["inherited_files"]:
        old = project_path(item["v1_path"])
        new = project_path(item["v2_path"])
        require(sha256(old) == item["sha256"], f"v1 inherited file changed: {old}")
        require(new.is_file() and sha256(new) == item["sha256"], f"v2 inherited evidence changed: {new}")
    inherited_manifest = baseline["inherited_reanalysis_manifest"]
    manifest_path = project_path(inherited_manifest["v2_path"])
    require(sha256(manifest_path) == inherited_manifest["sha256"], "Inherited reanalysis manifest was rewritten")
    manifest = read_json(manifest_path)
    original_items = manifest["input_files"] + manifest["output_files"]
    verify_source_hashes(original_items)
    original_script = project_path(manifest["script"])
    require(sha256(original_script) == manifest["script_sha256"], "Original v1 reanalysis script changed")
    return {
        "revision_baseline": str(BASELINE_PATH.relative_to(ROOT)),
        "revision_baseline_sha256": sha256(BASELINE_PATH),
        "v1_files_preserved": len(baseline["v1_files"]),
        "v1_required_artifacts": baseline["v1_required_artifacts"],
        "v2_inherited_files_verified": len(baseline["inherited_files"]),
        "inherited_files": baseline["inherited_files"],
        "original_manifest_items_verified": len(original_items),
        "original_manifest_unchanged": True,
        "original_analysis_script": manifest["script"],
    }


def compact(text: str) -> str:
    return re.sub(r"\s+", "", text)


def uncomment(text: str) -> str:
    return re.sub(r"(?<!\\)%[^\n]*", "", text)


def expand_source(path: Path, active: tuple[Path, ...] = ()) -> tuple[str, set[Path]]:
    """Expand actual input/include files to discover tables and labels dynamically."""
    path = path.resolve()
    require(path.is_relative_to(ROOT.resolve()), f"TeX input outside paper_v2: {path}")
    require(path not in active, f"Recursive TeX input: {path}")
    require(path.is_file(), f"Missing TeX input: {path}")
    source = uncomment(path.read_text(encoding="utf-8"))
    used = {path}

    def replace(match):
        child = (path.parent / match.group(1)).resolve()
        if not child.suffix:
            child = child.with_suffix(".tex")
        expanded, child_files = expand_source(child, active + (path,))
        used.update(child_files)
        return expanded

    return re.sub(r"\\(?:input|include)\s*\{([^}]+)\}", replace, source), used


def source_signature(source: str) -> dict:
    return {
        "citation_commands": [
            [key.strip() for key in group.split(",")]
            for group in re.findall(r"\\cite\w*\*?(?:\[[^\]]*\]){0,2}\{([^}]+)\}", source)
        ],
        "labels": re.findall(r"\\label\{([^}]+)\}", source),
        "references": re.findall(r"\\(?:ref|eqref|autoref)\{([^}]+)\}", source),
        "equations": [compact(match[1]) for match in re.findall(
            r"\\begin\{(equation\*?|align\*?|gather\*?)\}(.*?)\\end\{\1\}", source, re.S)],
        "display_math": [compact(value) for value in re.findall(r"\\\[(.*?)\\\]", source, re.S)],
        "inline_math": [compact(value) for value in re.findall(r"(?<!\\)\$(.*?)(?<!\\)\$", source, re.S)]
                       + [compact(value) for value in re.findall(r"\\\((.*?)\\\)", source, re.S)],
        "figures": re.findall(r"\\includegraphics\*?(?:\[[^\]]*\])?\{([^}]+)\}", source),
        "section_levels": re.findall(r"\\(section|subsection|subsubsection)\*?\{", source),
        "table_count": len(re.findall(r"\\begin\{table\*?\}", source)),
        "figure_count": len(re.findall(r"\\begin\{figure\*?\}", source)),
    }


def check_sources() -> tuple[dict, list[dict]]:
    bib_path = ROOT / "shared/references.bib"
    bib = bib_path.read_text(encoding="utf-8")
    keys = re.findall(r"@\w+\s*\{\s*([^,\s]+)", bib)
    require(len(keys) == len(set(keys)), "Duplicate bibliography keys")
    signatures, inventories, bibliography_usage = {}, set(), {}
    for lang in ("en", "zh"):
        source, files = expand_source(ROOT / f"manuscript_{lang}/main.tex")
        inventories.update(files)
        sig = source_signature(source)
        signatures[lang] = sig
        cited = {key for group in sig["citation_commands"] for key in group}
        require(cited <= set(keys), f"Unresolved bibliography keys ({lang}): {cited - set(keys)}")
        require(not re.search(r"\b(?:TODO|TBD|INSERT HERE)\b|\[XXX\]", source), f"Unfilled prose: {lang}")
        require(len(sig["labels"]) == len(set(sig["labels"])), f"Duplicate labels: {lang}")
        require(set(sig["references"]) <= set(sig["labels"]), f"Undefined source references: {lang}")
        for name in sig["figures"]:
            figure = ROOT / "figures" / name
            if not figure.suffix:
                figure = figure.with_suffix(".pdf")
            require(figure.is_file(), f"Missing figure: {figure}")
            inventories.add(figure.resolve())
        bibliography_usage[lang] = {"cited": sorted(cited), "uncited": sorted(set(keys) - cited)}
    for key in signatures["en"]:
        require(signatures["en"][key] == signatures["zh"][key], f"Bilingual {key} mismatch")
    inventories.add(bib_path.resolve())
    source_files = [{"path": p.relative_to(ROOT).as_posix(), "sha256": sha256(p)} for p in sorted(inventories)]
    sig = signatures["en"]
    return {
        "source_math_and_reference_equivalence": True,
        "bibliography_entries": len(keys), "bibliography_keys": keys,
        "bibliography_usage": bibliography_usage,
        "source_counts": {key: len(value) if isinstance(value, list) else value for key, value in sig.items()},
        "tables_in_each_version": sig["table_count"],
        "figures_in_each_version": sig["figure_count"],
        "signatures": signatures,
    }, source_files


def check_compilation() -> tuple[dict, dict]:
    (QA / "text").mkdir(parents=True, exist_ok=True)
    logs, pdfs = {}, {}
    for lang in ("en", "zh"):
        source_dir = ROOT / f"manuscript_{lang}"
        log = (source_dir / "main.log").read_text(encoding="utf-8", errors="replace")
        blg = (source_dir / "main.blg").read_text(encoding="utf-8", errors="replace")
        errors = [line for line in (log + "\n" + blg).splitlines()
                  if re.search(r"undefined|Missing character|^!|^Warning--|Rerun to get", line, re.I)]
        boxes = [line for line in log.splitlines() if "Overfull" in line or "Underfull" in line]
        require(not errors, f"Compilation/citation errors ({lang}): {errors}")
        logs[lang] = {"errors": errors, "box_warnings": boxes}
        pdf_path = ROOT / "release" / PDF_NAMES[lang]
        require(pdf_path.is_file(), f"Build v2 PDF first: {pdf_path}")
        require(sha256(pdf_path) == sha256(source_dir / "main.pdf"), f"Release PDF differs from compiled PDF: {lang}")
        reader = PdfReader(pdf_path)
        text_pages = [page.extract_text() or "" for page in reader.pages]
        require(bool(text_pages) and all(len(text.strip()) > 20 for text in text_pages), f"Blank/textless PDF page: {lang}")
        require(all(abs(float(page.mediabox.width) - 595.276) < 1 and abs(float(page.mediabox.height) - 841.89) < 1
                    for page in reader.pages), f"Unexpected page size: {lang}")
        text = "\n\n".join(f"--- Page {i + 1} ---\n{page}" for i, page in enumerate(text_pages))
        (QA / f"text/{lang}.txt").write_text(text, encoding="utf-8")
        require("[?]" not in text, f"Unresolved printed citation: {lang}")
        pdfs[lang] = {"path": str(pdf_path.relative_to(ROOT)), "pages": len(reader.pages),
                      "size_bytes": pdf_path.stat().st_size, "sha256": sha256(pdf_path),
                      "extracted_text_characters": sum(map(len, text_pages))}
    return logs, pdfs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--provenance-only", action="store_true")
    mode.add_argument("--sources-only", action="store_true")
    args = parser.parse_args()
    QA.mkdir(exist_ok=True)
    baseline = read_json(BASELINE_PATH)
    report = {"date": baseline["date"], "revision": "paper_v2", "provenance": verify_provenance(),
              "new_training_runs": 0, "new_inference_runs": 0}
    if args.provenance_only:
        filename = "provenance_checks.json"
    else:
        source_report, source_files = check_sources()
        report.update(source_report)
        report["source_files"] = source_files
        filename = "source_checks.json" if args.sources_only else "manuscript_checks.json"
        if not args.sources_only:
            report["compilation"], report["pdfs"] = check_compilation()
            report["visual_qa"] = "See qa/visual_review.md; not inferred by this script."
    (QA / filename).write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key not in ("signatures", "source_files")},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
