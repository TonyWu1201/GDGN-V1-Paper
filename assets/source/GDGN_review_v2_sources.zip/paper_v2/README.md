# GDGN 叙述性综述与诊断案例：正式稿

日期：2026-10-12。本稿以按 anti-defensive-writing skill 润色的第二版为基础，按用户要求整理为正式稿。中英文 PDF 已移除页眉和首页的版本／修订日期标记，并统一标题区间距及 PDF 标题元数据。目录与文件名保留 `paper_v2`，便于沿用现有编译与来源核查流程；`paper_v1` 原始版本保留。

英文题目：**Tracing biological priors in cancer drug response prediction: A narrative review and diagnostic GDGN case study**。

中文题目：**癌症药物响应预测中生物先验的作用路径：叙述性综述与 GDGN 诊断案例研究**。

## 阅读入口

| 文件 | 内容 |
|---|---|
| `release/GDGN_review_v2_en.pdf` | 英文正式稿，14 页 |
| `release/GDGN_review_v2_zh.pdf` | 中文正式稿，12 页 |
| `manuscript_en/main.tex`、`manuscript_zh/main.tex` | 可编辑正文 |
| `release/GDGN_review_v2_sources.zip` | 可独立编译的 LaTeX 源码包 |
| `revision_notes.md` | 润色与正式稿排版修改记录 |
| `shared/references.bib` | 中英文稿共享的 24 篇原始文献 |
| `results/`、`provenance/` | 第一版统计结果、来源与版本继承链 |
| `qa/manuscript_checks.json`、`qa/visual_review.md` | 双语、编译、证据与版面核查 |

文章围绕读出、初始化和拓扑三条路径，连接注意力解释、预训练迁移与图结构收益的科学主张及评价比较。GDGN 案例先呈现关系输入敏感性，再分析注意力与输入归因，最后给出信息覆盖和预测背景。正文共用四幅图、四张表；中文正文、表格和图注完整翻译，图内英文标签沿用共享矢量源。

本版使用 B4 及前序材料。统计文件与三个数据图继承自第一版，新增训练 0 次、检查点推理 0 次。必要的适用范围集中于讨论，详细方法口径和档案元数据置于附录 A。

## 编译

项目根目录下运行：

```powershell
& './paper_v2/scripts/build_manuscripts.ps1'
```

可加 `-Language en` 或 `-Language zh` 单独构建。脚本依次运行 XeLaTeX、BibTeX、两次 XeLaTeX，日志写入 `paper_v2/qa/compile/`，最终 PDF 写入 `paper_v2/release/`。当前环境为 TeX Live 2026。

源码包解压后保留目录结构，可进入对应 `manuscript_` 目录，依次运行 `xelatex main.tex`、`bibtex main`、两次 `xelatex main.tex`。中文使用 Windows 字体，其他操作系统需在中文主稿调整字体配置。所有图、表和参考文献均已包含。

## 一致性与来源核查

遵循项目规范，Python 使用 uv。本轮沿用已配置依赖的 bundled runtime：

```powershell
$paperPython = 'C:/Users/13249/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$env:UV_CACHE_DIR = Join-Path (Get-Location) '.uv-cache'
uv run --no-project --python $paperPython python paper_v2/scripts/check_manuscripts.py --provenance-only
uv run --no-project --python $paperPython python paper_v2/scripts/check_manuscripts.py --sources-only
uv run --no-project --python $paperPython python paper_v2/scripts/check_manuscripts.py
```

最后一条在编译完成后运行，核对双语公式、引文、标签、交叉引用、图表数与编译日志，并验证第一版 126 个文件未变、继承的 11 个统计／数据图文件一致及原再分析来源链。PDF 另外逐页渲染核查。

`provenance/reanalysis_manifest.json` 保留第一版的原始路径，`revision_baseline.json` 将这些来源与第二版连接。完整来源核查依赖原项目和 `paper_v1`；源码包支持独立编译。`scripts/reanalyse_legacy.py` 和 `prepare_manuscript.py` 是继承的再分析源程序，本次润色无需执行。

最终核查和目视检查记录完成后，执行 `uv run --no-project --python $paperPython python paper_v2/scripts/prepare_release.py` 可重新打包，并生成发布校验清单。
